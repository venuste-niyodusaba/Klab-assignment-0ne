import React from "react";
import pc1 from "../assets/pc1.png";
import back from "../assets/back.jpeg";
import backk from "../assets/backk.jpeg";

function Services() {
  const services = [
    { id: 1, name: "Diagnosing and Mechanics", img: pc1, delay: "0s" },
    { id: 2, name: "Background Designing and Setting", img: back, delay: "0.2s" },
    { id: 3, name: "House Interior Design", img: backk, delay: "0.4s" },
  ];

  return (
    <div className="py-16">
      <h2 className="text-3xl font-bold text-center mb-10">Our Services</h2>

      <div className="flex flex-row items-center justify-center gap-10">
        {services.map((service) => (
          <div
            key={service.id}
            className="w-50 h-40 mb-2 animate-slideIn"
            style={{ animationDelay: service.delay }}
          >
            <img
              src={service.img}
              alt={service.name}
              className="w-full h-28 object-cover rounded"
            />
            <p className="text-center mt-2">{service.name}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

export default Services;
