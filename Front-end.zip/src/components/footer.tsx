function Footer() {
  return (
    <div className="fixed bottom-0 left-0 w-full bg-blue-500 text-white py-4 flex justify-center items-center">
      <p className="text-sm">&copy; 2025 Klab. All rights reserved.</p>
    </div>
  )
}

export default Footer
