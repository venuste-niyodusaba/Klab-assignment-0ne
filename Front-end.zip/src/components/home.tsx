import React, { useState } from 'react';

function Home() {
    const [count, setCount] = useState<number>(0);

    const increase = () => {
        setCount(count + 1);
    };

    const decrease = () => {
        setCount(count - 1);
    };

    return (
        <div className="text-2xl flex flex-col items-center pt-20">
            <div className="flex flex-row space-x-4">
                <button 
                    className="bg-green-200 w-40 h-10 pt-2" 
                    onClick={increase}
                >
                    Increase
                </button>
                <button 
                    className="bg-red-500 w-40 h-10 pt-2" 
                    onClick={decrease}
                >
                    Decrease
                </button>
            </div>
            <p className="mt-4">
                Display: <span className="text-green-500">{count}</span>
            </p>
        </div>
    );
}

export default Home;
