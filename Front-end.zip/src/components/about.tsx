function About() {
  return(
    <div className=" text-2xl font-semibold  pt-11">
    About Us
    </div>
  )
}   
export default About;