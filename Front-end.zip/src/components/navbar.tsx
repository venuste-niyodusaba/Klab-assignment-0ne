import image from '../assets/image.png'
import { NavLink } from 'react-router-dom'

function NavbarPage() {
  const baseStyle = "px-2 hover:text-gray-300";
  const activeStyle = "text-yellow-300 font-bold"; 

  return (
    <div className="fixed top-0 left-0 w-full z-20 bg-blue-500 shadow">
      <div className="flex items-center justify-between py-3 pr-2 pl-2 w-full">
        
        <img src={image} alt="logo" className="pr-1 pl-1 w-12 h-10" />

        <ul className="flex flex-row gap-6 text-white font-semibold">
          <NavLink to="/home" className={({ isActive }) => isActive ? activeStyle : baseStyle}>
            HOME
          </NavLink>
          <NavLink to="/services" className={({ isActive }) => isActive ? activeStyle : baseStyle}>
            SERVICES
          </NavLink>
          <NavLink to="/about" className={({ isActive }) => isActive ? activeStyle : baseStyle}>
            ABOUT
          </NavLink>
          <NavLink to="/project" className={({ isActive }) => isActive ? activeStyle : baseStyle}>
            PROJECTS
          </NavLink>
          <NavLink to="/contact" className={({ isActive }) => isActive ? activeStyle : baseStyle}>
            CONTACT US
          </NavLink>
        </ul>

        <div className="justify-center gap-10 space-x-3">
          <NavLink to="/login">
            <button className="bg-white text-blue-400 px-4 py-2 outline-double hover:bg-gray-600 pr-5 pl-10 font-semibold">
              LOGIN
            </button>
          </NavLink>
          <NavLink to="/register">
            <button className="bg-white text-blue-400 px-4 py-2 outline-double hover:bg-gray-600 pr-5 pl-10 font-semibold">
              Register
            </button>
          </NavLink>
        </div>
      </div>
    </div>
  )
}

export default NavbarPage
