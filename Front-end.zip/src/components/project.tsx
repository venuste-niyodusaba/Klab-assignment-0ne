function Project() {
  return(
    <div className=" text-2xl font-semibold  pt-11">
   my Projects
    </div>
  )
}   
export default Project;