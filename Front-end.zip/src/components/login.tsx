import { useNavigate } from 'react-router-dom';
import { useState } from 'react';

function Login() {
  const navigate = useNavigate();
  const [isOpen, setIsOpen] = useState(true); // track modal open/close

  const handleModalClose = () => {
    setIsOpen(false);
  };

  if (!isOpen) return null; // hide form if closed

  return (
    <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50">
      <div className="relative flex flex-col items-center justify-center h-[30rem] w-[26rem] bg-white shadow-lg rounded-lg p-6">
        
        {/* Close X button */}
        <button
          onClick={handleModalClose}
          className="absolute top-3 right-3 text-gray-600 hover:text-red-500 text-xl font-bold"
        >
          ×
        </button>

        <h1 className="text-2xl font-bold mb-4">LOGIN</h1>

        <form className="flex flex-col gap-4 w-full">
          <input 
            type="text" 
            placeholder="User name" 
            className="border border-gray-300 rounded px-5 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500" 
            required
          />
          <input 
            type="email" 
            placeholder="Email" 
            className="border border-gray-300 rounded px-5 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500" 
            required
          />
          <input 
            type="password" 
            placeholder="Password" 
            className="border border-gray-300 rounded px-5 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500" 
            required 
          />

          <button 
            type="submit" 
            className="bg-blue-500 text-white font-semibold py-2 rounded hover:bg-blue-600 w-32"
          >
            Login
          </button>

          <button type="button" className="text-blue-900">
            Forgot password?
          </button>

          <p>
            No account?{" "}
            <button 
              type="button" 
              className="text-blue-900"
              onClick={() => navigate('/register')}
            >
              Register
            </button>
          </p>
        </form>
      </div>
    </div>
  );
}

export default Login;
