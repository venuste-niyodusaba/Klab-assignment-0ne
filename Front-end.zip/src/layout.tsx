
import {Outlet} from 'react-router-dom';
import NavbarPage from './components/navbar';
import FooterPage from './components/footer';
function LayoutHandling()
    {
        return(
            <>
<NavbarPage/>
<Outlet/>
<FooterPage/>   
            </>
        )
    }
export default LayoutHandling;