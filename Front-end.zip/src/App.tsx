import { useState } from 'react'
import './App.css'
import './index.css'
import About from './components/about'
import Services from './components/services'  
import {BrowserRouter} from 'react-router-dom'
import {Routes} from 'react-router-dom'
import {Route} from 'react-router-dom'
import LayoutHandling from './layout'
import NavbarPage from './components/navbar'
import FooterPage from './components/footer'
import Home from './components/home'
import Project from './components/project'
import Contact from './components/contact'
import Login from './components/login'
import RegisterForm from './components/registe'

function App() {

  return (

<BrowserRouter>
<Routes>
  <Route path='/' element={<LayoutHandling/>}>
  <Route index element={<Home/>}/>
  <Route path='/home' element={<Home/>}/>
  <Route path='/services' element={<Services/>}/>
  <Route path='/about' element={<About/>}/>
  <Route path='/project' element={<Project/>}/>
   <Route path='/contact' element={<Contact/>}/>
   <Route path='/login' element={<Login />} />
  <Route path='/register' element={<RegisterForm />} />
  </Route>
</Routes>

</BrowserRouter> 
  )
    
}

export default App
